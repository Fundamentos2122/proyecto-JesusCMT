<?php

    if(session_status() !== PHP_SESSION_ACTIVE) session_start();
    
    include("../models/DB.php");
    include("../models/Meme.php");
    include("../models/Comentario.php");

    try{
        $connection = DBConnection::getConnection();
    }
    catch(PDOException $e){
        error_log("Error de conexion -- " . $e, 0);

        exit;
    }

    if($_SERVER["REQUEST_METHOD"] == "GET"){
        //Leer    
        if(array_key_exists("meme_id", $_GET)){
            //Traer la información de los comentarios de un meme
            $meme_id = $_GET["meme_id"];
            try{
                $query = $connection->prepare("SELECT * FROM comentarios WHERE meme_id = :meme_id");
                $query->bindParam(":meme_id", $meme_id, PDO::PARAM_INT);
                $query->execute();

                while($row = $query->fetch(PDO::FETCH_ASSOC)){
                    $comentario = new Comentario($row["id"], $row["meme_id"], $row["usuario_id"], $row["texto"], $row["num_likes"]);

                    // $meme->returnJson();

                    echo 
                    "<!-- Comentario -->
                    <div class='row'>
                        <div class='col-1'></div>
                        <div class='col-1' style='padding: 0.35em;'>
                            <img src='Imagenes/PP.png' alt='Profile Picture' class='profilePic'>
                        </div>
                        <div class='col-9'>
                            <div class='row display-6'>
                                <div class='username username" . $comentario->getUsuarioId() . "' username_id='". $comentario->getUsuarioId() ."'></div>
                                <script>
                                    document.addEventListener('DOMContentLoaded', function(){
                                        console.log('Hola');
                                        getUsername(" . $comentario->getUsuarioId() . ");
                                    });
                                </script>
                            </div>
                            <div class='row border bg-secondary text-dark' style='border-radius: 10px; width: fit-content; max-width: 100%; padding: 0.25em 1em;'>" . 
                                $comentario->getTexto()
                             . "</div>
                            <div class='row'>
                                <button class='btn text-danger border-0 bg-bg' type='button'>
                                    <i class='material-icons' style='font-size: 1em;'>favorite_border</i>
                                    <div style='font-size: 1em; display: inline-block;' class='text-danger'>" . $comentario->getNumLikes() . "</div>
                                </button>
                            </div>
                        </div>
                    </div>";
                }
            }
            catch(PDOException $e){
                error_log("Error en query -- " . $e, 0);

                exit();
            }
        }
        elseif(array_key_exists("usuario_id", $_GET)){
            //Traer una lista de registros para la página del usuario
            $usuario_id = $_GET["usuario_id"];
            try{
                $query = $connection->prepare("SELECT * FROM comentarios WHERE usuario_id = :usuario_id");
                $query->bindParam(":usuario_id", $usuario_id, PDO::PARAM_INT);
                $query->execute();
                
                while($row = $query->fetch(PDO::FETCH_ASSOC)){
                    $comentario = new Comentario($row["id"], $row["meme_id"], $row["usuario_id"], $row["texto"], $row["num_likes"]);

                    echo "<br>
                        <div class='row'>
                            <div class='col-1'></div>
                            <div class='col-1'>
                                <div class='row' style='height: 2em;'>
                                    <a href='http://localhost/Intermemedio/views/Meme_comentarios.php?id=". $comentario->getMemeId() ."'>
                                        <img src='Imagenes/M10.jpg' alt='Meme' class='meme-micro' style='max-width: 100%;'>
                                    </a>
                                </div>
                            </div>
                            <div class='col-1' style='margin: 0; padding: 0.35em;'>
                                <img src='Imagenes/PP.png' alt='Profile Picture' class='profilePic'>
                            </div>
                            <div class='col-8'>
                                <div class='row display-6'>
                                </div>
                                <div class='row border bg-secondary text-dark' style='border-radius: 10px; width: fit-content; max-width: 100%; padding: 0.25em;'>
                                    ". $comentario->getTexto() ."
                                </div>
                            </div>
                        </div>";
                }
            }
            catch(PDOException $e){
                error_log("Error en query -- " . $e, 0);

                exit();
            }
        }
        else{
            //Traer el listado de todos los registros
            try{
                $query = $connection->prepare("SELECT * FROM comentarios");
                $query->execute();

                while($row = $query->fetch(PDO::FETCH_ASSOC)){
                    $comentario = new Comentario($row["id"], $row["meme_id"], $row["usuario_id"], $row["texto"], $row["num_likes"]);

                    echo 
                    "<!-- Comentario -->
                    <div class='row'>
                        <div class='col-1'></div>
                        <div class='col-1' style='padding: 0.35em;'>
                            <img src='Imagenes/PP.png' alt='Profile Picture' class='profilePic'>
                        </div>
                        <div class='col-9'>
                            <div class='row display-6'>
                                <div class='username" . $comentario->getUsuarioId() . "'></div>
                                <script>
                                    document.addEventListener('DOMContentLoaded', function(){
                                        console.log('Hola');
                                        getUsername(" . $comentario->getUsuarioId() . ");
                                    });
                                </script>
                            </div>
                            <div class='row border bg-secondary text-dark' style='border-radius: 10px; width: fit-content; max-width: 100%; padding: 0.25em 1em;'>" . 
                                $comentario->getTexto()
                             . "</div>
                            <div class='row'>
                                <button class='btn text-danger border-0 bg-bg' type='button'>
                                    <i class='material-icons' style='font-size: 1em;'>favorite_border</i>
                                    <div style='font-size: 1em; display: inline-block;' class='text-danger'>" . $comentario->getNumLikes() . "</div>
                                </button>
                            </div>
                        </div>
                    </div>";
                }
            }
            catch(PDOException $e){
                error_log("Error en query -- " . $e, 0);

                exit();
            }
        }
    }
    elseif ($_SERVER["REQUEST_METHOD"] == "POST"){
        if($_POST["_method"] == "POST"){
            //Guardar
            $meme_id = $_POST["meme_id"];
            $usuario_id = $_SESSION["id"];
            $texto = $_POST["texto"];
            $num_likes = 0;
            try{
                $query = $connection->prepare('INSERT INTO comentarios VALUES(NULL, :meme_id, :usuario_id, :texto, :num_likes)');
                $query->bindParam(':meme_id', $meme_id, PDO::PARAM_INT);
                $query->bindParam(':usuario_id', $usuario_id, PDO::PARAM_INT);
                $query->bindParam(':texto', $texto, PDO::PARAM_STR);
                $query->bindParam(':num_likes', $num_likes, PDO::PARAM_INT);
                $query->execute();

                if($query->rowCount()==0){
                    //error
                    exit();
                }

                header("Location: http://localhost/Intermemedio/views/Meme_comentarios.php?id=". $meme_id);
            }
            catch(PDOException $e){
                error_log("Error en query -- " . $e, 0);

                exit;
            }
        }
        else if($_POST["_method"] == "PUT"){
            //Actualizar

        }
        else if($_POST["_method"] == "DELETE"){
            //Eliminar
            $meme_id = $_POST["meme_id"];

            try{
                $query = $connection->prepare('DELETE FROM memes WHERE meme_id = :meme_id');
                $query->bindParam(':meme_id', $meme_id, PDO::PARAM_INT);
                $query->execute();

                if($query->rowCount()==0){
                    //Error
                    exit();
                }
                header("Location: http://localhost/Intermemedio/");
            }
            catch(PDOException $e){
                error_log("Error en query -- " . $e, 0);

                exit;
            }
        }
        else{
            //Error
        }
    }
?>
