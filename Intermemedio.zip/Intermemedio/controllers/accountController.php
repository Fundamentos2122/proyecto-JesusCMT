<?php

    include("../models/DB.php");
    include("../models/Usuario.php");

    try{
        $connection = DBConnection::getConnection();
    }
    catch(PDOException $e){
        error_log("Error de conexion -- " . $e, 0);

        exit;
    }

    if($_SERVER["REQUEST_METHOD"] == "GET"){
        //Leer
        if(array_key_exists("id", $_GET)){
            //Traer la información de un elemento
            $id = $_GET["id"];
            try{
                $query = $connection->prepare("SELECT * FROM usuarios WHERE id = :id");
                $query->bindParam(":id", $id, PDO::PARAM_INT);
                $query->execute();

                while($row = $query->fetch(PDO::FETCH_ASSOC)){
                    $usuario = new Usuario($row["id"], $row["correo"], $row["nombre_usuario"], $row["contrasena"], $row["rol"]);

                    $usuario->returnJson();
                }
            }
            catch(PDOException $e){
                error_log("Error en query -- " . $e, 0);

                exit();
            }
        }
        else{
            //Traer el listado de todos los registros
            try{
                $query = $connection->prepare("SELECT * FROM usuarios");
                $query->execute();

                while($row = $query->fetch(PDO::FETCH_ASSOC)){
                    $usuario = new Usuario($row["id"], $row["correo"], $row["nombre_usuario"], $row["contrasena"], $row["rol"]);

                    // echo 
                    // "<div class='col-3'>" . 
                    //     "<a href='alumno_detalles.php?id=+" . $alumno->getId() . "'>" .
                    //         "<img src=\"data:image/jpeg;base64," . $alumno->getFoto() . "\" alt='' class='image-fluid card'>" . 
                    //         "<p>" . $alumno->getNombreCompleto() . "</p>" .
                    //     "</a>" .
                    // "</div>";
                }
            }
            catch(PDOException $e){
                error_log("Error en query -- " . $e, 0);

                exit();
            }
        }
    }
    elseif ($_SERVER["REQUEST_METHOD"] == "POST"){
        if($_POST["_method"] == "POST"){
            //Guardar
            $correo = $_POST["correo"];
            $nombre_usuario = $_POST["nombre_usuario"];
            $contrasena = $_POST["contrasena"];
            $rol = "normal";
            // $rol = $_POST["rol"];

            try{
                $query = $connection->prepare('INSERT INTO usuarios VALUES(NULL, :correo, :nombre_usuario, :contrasena, :rol)');
                $query->bindParam(':correo', $correo, PDO::PARAM_STR);
                $query->bindParam(':nombre_usuario', $nombre_usuario, PDO::PARAM_STR);
                $query->bindParam(':contrasena', $contrasena, PDO::PARAM_STR);
                $query->bindParam(':rol', $rol, PDO::PARAM_STR);
                $query->execute();

                if($query->rowCount()==0){
                    //error
                    exit();
                }

                //Iniciar sesión
                $query2 = $connection->prepare('SELECT * FROM usuarios WHERE correo = :correo AND nombre_usuario = :nombre_usuario AND contrasena = :contrasena');
                $query2->bindParam(':correo', $correo, PDO::PARAM_STR);
                $query2->bindParam(':nombre_usuario', $nombre_usuario, PDO::PARAM_STR);
                $query2->bindParam(':contrasena', $contrasena, PDO::PARAM_STR);
                $query2->execute();

                if($query2->rowCount() == 0){
                    //No se encontró el usuario
                    header("Location: http://localhost/Intermemedio/views/Log_in.php?error=Usuario y/o contraseña inválidos");

                    exit();
                }
                $usuario;
                while($row = $query2->fetch(PDO::FETCH_ASSOC)){
                    $usuario = new Usuario($row["id"], $row["correo"], $row["nombre_usuario"], $row["contrasena"], $row["rol"]);
                }

                session_start();
                $_SESSION["id"] = $usuario->getId();
                $_SESSION["correo"] = $usuario->getCorreo();
                $_SESSION["nombre_usuario"] = $usuario->getNombreUsuario();
                $_SESSION["rol"] = $usuario->getRol();


                header("Location: http://localhost/Intermemedio/");
            }
            catch(PDOException $e){
                error_log("Error en query -- " . $e, 0);

                exit();
            }
        }
        else if($_POST["_method"] == "PUT"){
            //Actualizar
            exit();
        }
        else if($_POST["_method"] == "DELETE"){
            //Eliminar
            exit();
        }
        else{
            //Error
            header("Location: http://localhost/practicaphp/views/error.php?error=Error: No se reconoce el método de request");
        }
    }

?>