<?php

    if(session_status() !== PHP_SESSION_ACTIVE) session_start();
    
    include("../models/DB.php");
    include("../models/Meme.php");

    try{
        $connection = DBConnection::getConnection();
    }
    catch(PDOException $e){
        error_log("Error de conexion -- " . $e, 0);

        exit;
    }

    if($_SERVER["REQUEST_METHOD"] == "GET"){
        //Leer    
        if(array_key_exists("id", $_GET)){
            //Traer la información de un elemento según su ID
            $id = $_GET["id"];
            try{
                $query = $connection->prepare("SELECT * FROM memes WHERE id = :id");
                $query->bindParam(":id", $id, PDO::PARAM_INT);
                $query->execute();

                while($row = $query->fetch(PDO::FETCH_ASSOC)){
                    $meme = new Meme($row["id"], $row["imagen"], $row["usuario_id"], $row["categoria"], $row["tags"], $row["num_likes"]);

                    // $meme->returnJson();

                    $report = "";
                    // Validar que el usuario sea administrador
                    if(array_key_exists("nombre_usuario", $_SESSION) && $_SESSION["rol"] !== "admin"){
                        $report = 
                        "<li>
                            <a href='Home (Reportar).html' class='dropdown-item'>
                                <i class='material-icons'>flag</i> Reportar
                            </a>
                        </li>";
                    }
                    else{
                        $report = 
                        "<li>
                            <form id='form_delete' action='http://localhost/Intermemedio/controllers/memesController.php' method='POST'>
                                <input type='hidden' name='_method' value='DELETE'>
                                <input type='hidden' name='meme_id' value='". $meme->getId() ."'>
                                <input type='submit' value='Eliminar meme' class='dropdown-item bg-secondary btn-delete' style='width:100%;'>
                            </form>
                        </li>";
                    }

                    echo 
                    "<div>
                        <div class='row'>
                            <div class='col-1'></div>
                            <div class='col-10 border'>
                                <img src=\"data:image/jpeg;base64," . $meme->getImagen() . "\" alt='Meme' class='meme'>
                            </div>
                            <div class='col-1'></div>
                        </div>
                        <div class='row'>
                            <div class='col-1'></div>
                            <div class='col-10'>
                                <div class='bg-bg' style='display: inline-flex; justify-content: space-between; width: 100%;'>
                                    <div style='display: inline-block;'>
                                        <button class='btn text-danger border-0 bg-bg' type='button'>
                                            <i class='material-icons' style='font-size: 2em;'>favorite_border</i>
                                        </button>
                                        <div style='font-size: 1.9em; display: inline-block;' class='text-danger'>" . $meme->getNumLikes() . "</div>
                                    </div>
                                    <div style='display: inline-block; text-align: right;' class='dropdown'>
                                        <button class='btn text-dark border-0 bg-bg dropdown-toggle' type='button'>
                                            <i class='material-icons' style='font-size: 2em;'>more_horiz</i>
                                        </button>
                                        <!-- Menú desplegable -->
                                        <ul class='dropdown-menu' style='right: 0; text-align: left; z-index: 9000;'>
                                            <li>
                                                <a href='' class='dropdown-item'>
                                                    <i class='material-icons'>star_border</i> Favoritos
                                                </a>
                                            </li>
                                            <li>
                                                <a href='' class='dropdown-item'>
                                                    <i class='material-icons'>file_download</i> Descargar
                                                </a>
                                            </li>
                                            <li>
                                                <a href='' class='dropdown-item'>
                                                    <i class='material-icons'>share</i> Compartir
                                                </a>
                                            </li>
                                            ". $report ."
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class='col-1'></div>
                        </div>
                    </div>
                    <br><br>";
                }
            }
            catch(PDOException $e){
                error_log("Error en query -- " . $e, 0);

                exit();
            }
        }
        elseif(array_key_exists("categoria", $_GET)){
            //Traer una lista de registros según su categoría
            $categoria = $_GET["categoria"];
            try{
                $query = $connection->prepare("SELECT * FROM memes WHERE categoria = :categoria");
                $query->bindParam(":categoria", $categoria, PDO::PARAM_STR);
                $query->execute();

                while($row = $query->fetch(PDO::FETCH_ASSOC)){
                    $meme = new Meme($row["id"], $row["imagen"], $row["usuario_id"], $row["categoria"], $row["tags"], $row["num_likes"]);
                    $report = "";
                    // Validar que el usuario sea administrador
                    if(array_key_exists("nombre_usuario", $_SESSION) && $_SESSION["rol"] !== "admin"){
                        $report = 
                        "<li>
                            <a href='Home (Reportar).html' class='dropdown-item'>
                                <i class='material-icons'>flag</i> Reportar
                            </a>
                        </li>";
                    }
                    else{
                        $report = 
                        "<li>
                            <form id='form_delete' action='http://localhost/Intermemedio/controllers/memesController.php' method='POST'>
                                <input type='hidden' name='_method' value='DELETE'>
                                <input type='hidden' name='meme_id' value='". $meme->getId() ."'>
                                <input type='submit' value='Eliminar meme' class='dropdown-item bg-secondary btn-delete' style='width:100%;'>
                            </form>
                        </li>";
                    }

                    echo 
                    "<br><br>
                    <div>
                        <div class='row'>
                            <div class='col-1'></div>
                            <div class='col-10 border'>
                                <img src=\"data:image/jpeg;base64," . $meme->getImagen() . "\" alt='Meme' class='meme'>
                            </div>
                            <div class='col-1'></div>
                        </div>
                        <div class='row'>
                            <div class='col-1'></div>
                            <div class='col-10'>
                                <div class='bg-secondary' style='display: inline-flex; justify-content: space-between; width: 100%;'>
                                    <div style='display: inline-block;'>
                                        <button class='btn text-danger border-0 bg-secondary' type='button'>
                                            <i class='material-icons' style='font-size: 2em;'>favorite_border</i>
                                        </button>
                                        <div style='font-size: 1.9em; display: inline-block;' class='text-danger'>" . $meme->getNumLikes() . "</div>
                                        <a href='http://localhost/Intermemedio/views/Meme_comentarios.php?id=" . $meme->getId() . "' class='btn text-dark border-0 bg-secondary' type='button'>
                                            <i class='material-icons' style='font-size: 2em;'>forum</i>
                                        </a>
                                    </div>
                                    <div style='display: inline-block; text-align: right;' class='dropdown'>
                                        <button class='btn text-dark border-0 bg-secondary dropdown-toggle' type='button'>
                                            <i class='material-icons' style='font-size: 2em;'>more_horiz</i>
                                        </button>
                                        <!-- Menú desplegable -->
                                        <ul class='dropdown-menu' style='right: 0; text-align: left; z-index: 9000;'>
                                            <li>
                                                <a href='' class='dropdown-item'>
                                                    <i class='material-icons'>star_border</i> Favoritos
                                                </a>
                                            </li>
                                            <li>
                                                <a href='' class='dropdown-item'>
                                                    <i class='material-icons'>file_download</i> Descargar
                                                </a>
                                            </li>
                                            <li>
                                                <a href='' class='dropdown-item'>
                                                    <i class='material-icons'>share</i> Compartir
                                                </a>
                                            </li>
                                            ". $report ."
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class='col-1'></div>
                        </div>
                    </div>
                    <br><br>";
                }
            }
            catch(PDOException $e){
                error_log("Error en query -- " . $e, 0);

                exit();
            }
        }
        elseif(array_key_exists("usuario_id", $_GET)){
            //Traer una lista de registros según su categoría
            $usuario_id = $_GET["usuario_id"];
            try{
                $query = $connection->prepare("SELECT * FROM memes WHERE usuario_id = :usuario_id");
                $query->bindParam(":usuario_id", $usuario_id, PDO::PARAM_STR);
                $query->execute();

                while($row = $query->fetch(PDO::FETCH_ASSOC)){
                    $meme = new Meme($row["id"], $row["imagen"], $row["usuario_id"], $row["categoria"], $row["tags"], $row["num_likes"]);

                    echo 
                    "<div style='height: 12em; margin: 0.5em;' class='border'>
                        <a href='http://localhost/Intermemedio/views/Meme_comentarios.php?id=". $meme->getId() ."'>
                            <img src=\"data:image/jpeg;base64," . $meme->getImagen() . "\" alt='Meme' class='meme'>
                        </a>
                    </div>";
                }
            }
            catch(PDOException $e){
                error_log("Error en query -- " . $e, 0);

                exit();
            }
        }
        else{
            //Traer el listado de todos los registros
            try{
                $query = $connection->prepare("SELECT * FROM memes");
                $query->execute();

                while($row = $query->fetch(PDO::FETCH_ASSOC)){
                    $meme = new Meme($row["id"], $row["imagen"], $row["usuario_id"], $row["categoria"], $row["tags"], $row["num_likes"]);
                    $report = "";
                    // Validar que el usuario sea administrador
                    if(array_key_exists("nombre_usuario", $_SESSION) && $_SESSION["rol"] !== "admin"){
                        $report = 
                        "<li>
                            <a href='Home (Reportar).html' class='dropdown-item'>
                                <i class='material-icons'>flag</i> Reportar
                            </a>
                        </li>";
                    }
                    else{
                        $report = 
                        "<li>
                            <form id='form_delete' action='http://localhost/Intermemedio/controllers/memesController.php' method='POST'>
                                <input type='hidden' name='_method' value='DELETE'>
                                <input type='hidden' name='meme_id' value='". $meme->getId() ."'>
                                <input type='submit' value='Eliminar meme' class='dropdown-item bg-secondary btn-delete' style='width:100%;'>
                            </form>
                        </li>";
                    }

                    echo 
                    "<br><br>
                    <div>
                        <div class='row'>
                            <div class='col-1'></div>
                            <div class='col-10 border'>
                                <img src=\"data:image/jpeg;base64," . $meme->getImagen() . "\" alt='Meme' class='meme'>
                            </div>
                            <div class='col-1'></div>
                        </div>
                        <div class='row'>
                            <div class='col-1'></div>
                            <div class='col-10'>
                                <div class='bg-secondary' style='display: inline-flex; justify-content: space-between; width: 100%;'>
                                    <div style='display: inline-block;'>
                                        <button class='btn text-danger border-0 bg-secondary' type='button'>
                                            <i class='material-icons' style='font-size: 2em;'>favorite_border</i>
                                        </button>
                                        <div style='font-size: 1.9em; display: inline-block;' class='text-danger'>" . $meme->getNumLikes() . "</div>
                                        <a href='http://localhost/Intermemedio/views/Meme_comentarios.php?id=" . $meme->getId() . "' class='btn text-dark border-0 bg-secondary' type='button'>
                                            <i class='material-icons' style='font-size: 2em;'>forum</i>
                                        </a>
                                    </div>
                                    <div style='display: inline-block; text-align: right;' class='dropdown'>
                                        <button class='btn text-dark border-0 bg-secondary dropdown-toggle' type='button'>
                                            <i class='material-icons' style='font-size: 2em;'>more_horiz</i>
                                        </button>
                                        <!-- Menú desplegable -->
                                        <ul class='dropdown-menu' style='right: 0; text-align: left; z-index: 9000;'>
                                            <li>
                                                <a href='' class='dropdown-item'>
                                                    <i class='material-icons'>star_border</i> Favoritos
                                                </a>
                                            </li>
                                            <li>
                                                <a href='' class='dropdown-item'>
                                                    <i class='material-icons'>file_download</i> Descargar
                                                </a>
                                            </li>
                                            <li>
                                                <a href='' class='dropdown-item'>
                                                    <i class='material-icons'>share</i> Compartir
                                                </a>
                                            </li>
                                            ". $report ."
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class='col-1'></div>
                        </div>
                    </div>
                    <br><br>";
                }
            }
            catch(PDOException $e){
                error_log("Error en query -- " . $e, 0);

                exit();
            }
        }
    }
    elseif ($_SERVER["REQUEST_METHOD"] == "POST"){
        if($_POST["_method"] == "POST"){
            //Guardar
            $imagen = "";
            if(sizeof($_FILES) > 0){
                $tmp_name = $_FILES["imagen"]["tmp_name"];
                $imagen = file_get_contents($tmp_name);
            }
            $categoria = $_POST["categoria"];
            $tags = $_POST["tags"];
            $usuario_id = $_SESSION["id"];
            $num_likes = 0;

            try{
                $query = $connection->prepare('INSERT INTO memes VALUES(NULL, :imagen, :usuario_id, :categoria, :tags, :num_likes)');
                $query->bindParam(':imagen', $imagen, PDO::PARAM_STR);
                $query->bindParam(':usuario_id', $usuario_id, PDO::PARAM_INT);
                $query->bindParam(':categoria', $categoria, PDO::PARAM_STR);
                $query->bindParam(':tags', $tags, PDO::PARAM_STR);
                $query->bindParam(':num_likes', $num_likes, PDO::PARAM_INT);
                $query->execute();

                if($query->rowCount()==0){
                    //error
                    exit();
                }

                header("Location: http://localhost/Intermemedio/");
            }
            catch(PDOException $e){
                error_log("Error en query -- " . $e, 0);

                exit;
            }
        }
        else if($_POST["_method"] == "PUT"){
            //Actualizar

        }
        else if($_POST["_method"] == "DELETE"){
            //Eliminar
            $id = $_POST["meme_id"];

            try{
                $query = $connection->prepare('DELETE FROM memes WHERE id = :id');
                $query->bindParam(':id', $id, PDO::PARAM_INT);
                $query->execute();
                
                echo 
                    "<br>
                    <form action=\"comentarioController.php\" method=\"POST\" id=\"deleteForm\">
                    <input type='hidden' name='_method' value='DELETE'>
                    <input type='hidden' name='meme_id' value='". $id ."'>
                    </form>";

                ?>
                <script type="text/javascript">
                    console.log("Hey");
                    document.getElementById('deleteForm').submit(); // SUBMIT FORM
                </script>
                <?php

                if($query->rowCount()==0){
                    //Error
                    exit();
                }
                header("Location: http://localhost/Intermemedio/");
            }
            catch(PDOException $e){
                error_log("Error en query -- " . $e, 0);

                exit;
            }
        }
        else{
            //Error
        }
    }
?>