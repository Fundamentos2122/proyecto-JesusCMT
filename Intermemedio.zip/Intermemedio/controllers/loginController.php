<?php

    include("../models/DB.php");
    include("../models/Usuario.php");

    try{
        $connection = DBConnection::getConnection();
    }
    catch(PDOException $e){
        error_log("Error de conexion -- " . $e, 0);

        header("Location: http://localhost/Intermemedio/views/error.php?error=Error de conexión a la base de datos");

        exit;
    }

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        if($_POST["_method"] == "POST"){
            //Login
            $correo = $_POST["correo"];
            $contrasena = $_POST["contrasena"];

            try{
                $query = $connection->prepare('SELECT * FROM usuarios WHERE correo = :correo AND contrasena = :contrasena');
                $query->bindParam(':correo', $correo, PDO::PARAM_STR);
                $query->bindParam(':contrasena', $contrasena, PDO::PARAM_STR);
                $query->execute();

                if($query->rowCount() == 0){
                    //No se encontró el usuario
                    header("Location: http://localhost/Intermemedio/views/Log_in.php?error=Usuario y/o contraseña inválidos");

                    exit();
                }
                $usuario;
                while($row = $query->fetch(PDO::FETCH_ASSOC)){
                    $usuario = new Usuario($row["id"], $row["correo"], $row["nombre_usuario"], $row["contrasena"], $row["rol"]);
                }

                session_start();
                $_SESSION["id"] = $usuario->getId();
                $_SESSION["correo"] = $usuario->getCorreo();
                $_SESSION["nombre_usuario"] = $usuario->getNombreUsuario();
                $_SESSION["rol"] = $usuario->getRol();

                header("Location: http://localhost/Intermemedio/");
            }
            catch(PDOException $e){
                error_log("Error de conexion -- " . $e, 0);
        
                header("Location: http://localhost/Intermemedio/views/error.php?error=Error de inicio de sesión");

                exit;
            }
        }elseif($_POST["_method"] == "DELETE"){
            //Logout
            session_start();
            session_destroy();

            header("Location: http://localhost/Intermemedio/");

            exit();
        }
    }

?>