<?php
    header("Location: http://localhost/Intermemedio/views/Home (LI).php");
?>