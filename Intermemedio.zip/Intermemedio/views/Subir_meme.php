<?php
    //Verificar login
    session_start();
    if(!array_key_exists("nombre_usuario", $_SESSION)){
        header("Location: http://localhost/Intermemedio/");
        exit();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Icon list at https://www.w3schools.com/icons/icons_reference.asp (Scroll down to Google) -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="Framework/css/Framework.css">
    <title>Intermemedio - Subir meme</title>
</head>
<body>
    <?php
        //Verificar login
        if(array_key_exists("nombre_usuario", $_SESSION)){
            include("banner LI.php");
        }
        else{
            include("banner LO.php");
        }

        //Validar que el usuario sea administrador
        // if($_SESSION["rol"] !== "admin"){
        //     header("Location: http://localhost/practicaphp/views/");
        //     exit();
        // }
    ?>

    <div class="container-fluid container-lg">
    <form action="../controllers/memesController.php" method="post" class="row" autocomplete="off" enctype="multipart/form-data">
        <input type="hidden" name="_method" value="POST">

        <div class="bg-secondary" style="width:100%;">
            <div class="container-fluid container-lg">
                    <div class="row">
                        <div class="col-12">
                            <h1 class="text-primary" style="text-align: center;">Subir Meme</h1>
                        </div>
                    </div>
                    <!-- <div class="row">
                        <div class="col-1"></div>
                        <div class="col-10">
                            <img src="Imagenes/Drop Image.png" alt="Arrastra la imagen aquí" class="dropI">
                        </div>
                        <div class="col-1"></div>
                    </div> -->
                    <br>
                    <div class="row">
                        <div class="col-12" style="text-align: center;">
                            <!-- <button class="btn border-3 border-primary bg-secondary text-primary display-5" style="border-radius: 0.8em;">Buscar en dispositivo</button> -->
                            <label for="imagen">Imagen</label>
                            <br>
                            <input type="file" name="imagen" class="form-control btn border-3 border-primary bg-secondary text-primary display-5" style="border-radius: 0.8em;" required>
                        </div>
                    </div>
                    <br>
            </div>
        </div>

        <div class="bg-bg" style="width:100%;">
            <div class="container-fluid container-lg">
                <div class="row">
                    <div class="col-6">
                        <!-- <button style="width: 100%; text-align: left;">
                            <div style="display:flex; justify-content: space-between;">
                                <div>Categoría</div>
                                <i class="material-icons">arrow_drop_down</i>
                            </div>
                        </button>
                        <ul class="dropdown-menu" style="right: 1em; left: 1em; width: auto; z-index: 9000;">
                        <!!-- Añade la clase 'show' para mostrar --!!>
                            <li>
                                <a href="" class="dropdown-item">General</a>
                            </li>
                            <li>
                                <a href="" class="dropdown-item">Vida cotidiana</a>
                            </li>
                            <li>
                                <a href="" class="dropdown-item">Escuela</a>
                            </li>
                            <li>
                                <a href="" class="dropdown-item">Trabajo</a>
                            </li>
                            <li>
                                <a href="" class="dropdown-item">Películas y series</a>
                            </li>
                            <li>
                                <a href="" class="dropdown-item">Videojuegos</a>
                            </li>
                            <li>
                                <a href="" class="dropdown-item">Animales</a>
                            </li>
                            <li>
                                <a href="" class="dropdown-item">Política y sociedad</a>
                            </li>
                            <li>
                                <a href="" class="dropdown-item">Otros</a>
                            </li>
                        </ul> -->
                        <select name="categoria" id="categoria" class="btn" style="width: 100%; text-align: left;">
                            <option value="General" class="dropdown-item">General</option>
                            <option value="Vida Cotidiana" class="dropdown-item">Vida Cotidiana</option>
                            <option value="Escuela" class="dropdown-item">Escuela</option>
                            <option value="Trabajo" class="dropdown-item">Trabajo</option>
                            <option value="Películas y serie" class="dropdown-item">Películas y serie</option>
                            <option value="Videojuegos" class="dropdown-item">Videojuegos</option>
                            <option value="Animales" class="dropdown-item">Animales</option>
                            <option value="Política y sociedad" class="dropdown-item">Política y sociedad</option>
                            <option value="Otros" class="dropdown-item">Otros</option>
                        </select>
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-12">
                        <h4 style="margin-left: 1em;">Tags de la imagen:</h4>
                    </div>
                </div>
                <div class="row">
                    <!-- <div class="col-1"></div> -->
                    <div class="col-12" style="padding:0 2em;">
                        <label for="tags">Escribe las tags (etiquetas). Ejemplo: 'MCU Marvel Iron-man'</label>
                        <br>
                        <input type="text" name="tags" style="width:100%">
                    </div>
                    <!-- <div class="col-1"></div> -->
                </div>
            </div>
        </div>

        <div class="bg-secondary" style="width:100%;">
            <div class="container-fluid container-lg">
                <div class="row">
                    <div class="col-12" style="text-align: center;">
                        <!-- <button class="btn border-3 border-secondary bg-primary text-secondary display-5" style="border-radius: 0.8em;">Subir meme</button> -->
                        <input type="submit" value="Subir meme" class="btn border-3 border-secondary bg-primary text-secondary display-5" style="border-radius: 0.8em;">
                    </div>
                </div>
            </div>
        </div>

    </form>
    </div>
</body>
</html>