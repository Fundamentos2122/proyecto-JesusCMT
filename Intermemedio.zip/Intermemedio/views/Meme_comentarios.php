<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Icon list at https://www.w3schools.com/icons/icons_reference.asp (Scroll down to Google) -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="Framework/css/Framework.css">
    <title>Intermemedio - Comentarios</title>
</head>
<body class = "bg-bg">
    <?php
        //Verificar login
        if(array_key_exists("nombre_usuario", $_SESSION)){
            include("banner LI.php");
        }
        else{
            include("banner LO.php");
        }

        //Validar que el usuario sea administrador
        // if($_SESSION["rol"] !== "admin"){
        //     header("Location: http://localhost/practicaphp/views/");
        //     exit();
        // }
    ?>

    <div class="container-fluid container-lg bg-secondary">
        <div class="container-fluid container-lg bg-bg">
            <div id="memeDiv">
    
            </div>
            <?php
                if(!array_key_exists("id", $_GET)){

                    header("Location: http://localhost/Intermemedio/views/Home (LI).php");
                    exit();
                }

                $meme_id = $_GET["id"];
                //Verificar login
                if(array_key_exists("nombre_usuario", $_SESSION)){
                    echo 
                    "<form action='../controllers/comentarioController.php' method='POST' name='Comentar' style='width: 100%;'>
                        <input type='hidden' name='_method' value='POST'>
                        <input type='hidden' name='meme_id' value='" . $meme_id . "'>
                        <div class='row' style='align-items:center'>
                            <div class='col-1'></div>
                            <div class='col-7' style='display: inline-block;'>
                                <textarea name='texto'></textarea>
                            </div>
                            <div class='col-3' style='display: inline-block;'>
                                <input type='submit' class='btn border-3 border-secondary bg-primary text-secondary display-5 commentButton-toggle' style='border-radius: 0.8em; width: 100%; min-width:min-content;' value='Comentar'>
                                <button class='btn border-3 border-secondary bg-primary text-secondary display-5 commentButton-collapse' style='border-radius: 0.8em; width: 100%;'>
                                    <i class='material-icons' style='font-size: 1em;'>done</i>
                                </button>
                            </div>
                        </div>
                    </form>";
                }
            ?>
            
            <br>
            <div id="commentDiv">
                
            </div>
        </div>
    </div>

    <script src="Framework/js/framework.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function(){
            getMeme();
            getComentario();

            let userIds =  document.querySelectorAll(".username");
            userIds.forEach(element =>{
                var x =element.getAttribute("username_id");
                getUsername(x);
            });
        });

        function getMeme(){
            
            <?php 
                if(!array_key_exists("id", $_GET)){

                    header("Location: http://localhost/Intermemedio/views/Home (LI).php");
                    exit();
                }

                $id = $_GET["id"];
            ?>
            
            var xhttp = new XMLHttpRequest();

            var id = '<?php echo $id; ?>';

            xhttp.open("GET", "../controllers/memesController.php?id=" + id, false);

            xhttp.onreadystatechange = function(){
                if(this.readyState == 4){
                    var list = document.getElementById("memeDiv");
                    list.innerHTML = this.responseText;
                }
            }   
            
            xhttp.send();

            let dropdown_buttons =  document.querySelectorAll(`.${dropdown_class} > .${dropdown_toggle}`);
            dropdown_buttons.forEach(element =>{
                element.addEventListener("click", ToggleDropdown);
            });
        }

        function getComentario(){
            
            <?php 
                if(!array_key_exists("id", $_GET)){

                    header("Location: http://localhost/Intermemedio/views/Home (LI).php");
                    exit();
                }

                $meme_id = $_GET["id"];
            ?>
            
            var xhttp = new XMLHttpRequest();

            var meme_id = '<?php echo $meme_id; ?>';

            xhttp.open("GET", "../controllers/comentarioController.php?meme_id=" + meme_id, false);

            xhttp.onreadystatechange = function(){
                if(this.readyState == 4){
                    var list = document.getElementById("commentDiv");
                    list.innerHTML = this.responseText;
                }
            }   
            
            xhttp.send();
        }

        function getUsername(id){
            let divs =  document.querySelectorAll(".username" + id);

            divs.forEach(element =>{
                var xhttp = new XMLHttpRequest();
        
                xhttp.open("GET", "../controllers/accountController.php?id=" + id, false);
        
                xhttp.onreadystatechange = function(){
                    if(this.readyState == 4){
                        var User = JSON.parse(this.responseText);
                        element.innerHTML =User.nombre_usuario;
                    }
                };
        
                xhttp.send();
            });
        }
    </script>
</body>
</html>