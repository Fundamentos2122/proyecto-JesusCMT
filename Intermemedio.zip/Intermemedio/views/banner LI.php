<nav class="navbar bg-info" style="justify-content: space-between; align-items: flex-end;">
        <!-- Botón de búsqueda (móvil) -->
        <a href="Explore.php" class="navbar-toggle btn text-secondary border-0 bg-primary" type="button">
            <i class="material-icons" style="font-size: 2em;">search</i>
        </a>
        <!-- Opciones izquierda (escritorio) -->
        <div class="navbar-collapse" style="padding: 0.2em 0;">
            <button class="btn text-bg border-0 bg-primary"><i class="material-icons" style="font-size: 2em;">palette</i></button>
            <a href="Explore.php" class="btn text-secondary border-0 bg-primary display-5">Explorar</a>
            <a href="Subir_meme.php" class="btn text-secondary border-0 bg-primary display-5">Subir meme</a>
        </div>
        <!-- Titular -->
        <a href="Home (LI).php" class="navbar-brand h2">Intermemedio</a>
        <!-- Botón menú (móvil) -->
        <div class="navbar-toggle dropdown">
            <button class="navbar-toggle btn text-bg border-0 bg-primary dropdown-toggle" type="button">
                <i class="material-icons" style="font-size: 2em;">menu</i>
            </button>
            <!-- Menú desplegable -->
            <ul class="dropdown-menu" style="right: 0; z-index: 20000;">
                <li>
                    <a href="Subir_meme.php" class="dropdown-item">Subir meme</a>
                </li>
                <li>
                    <a href="Favoritos (LI).html" class="dropdown-item">Favoritos</a>
                </li>
                <li>
                    <a href="Memes subidos (LI).html" class="dropdown-item">Mis imágenes</a>
                </li>
                <li>
                    <a href="" class="dropdown-item">Cambiar colores</a>
                </li>
                <li>
                    <!-- <a href="Home (LO).html" class="dropdown-item">Cerrar sesión</a> -->
                    <form action="/Intermemedio/controllers/loginController.php" method="post">
                        <input type="hidden" name="_method" value="DELETE">
                        <input type="submit" value="Cerrar sesión" class="dropdown-item bg-secondary border-0" style="width: 100%; font-size:1em;">
                    </form>
                </li>
            </ul>
        </div>
        <!-- Opciones derecha (escritorio) -->
        <div class="navbar-collapse dropdown">
            <a href='<?php echo "User_page.php?id=" . $_SESSION["id"];?>' class="btn text-secondary border-0 bg-primary">
                <i class="material-icons" style="font-size: 4em;">account_circle</i>
            </a>
            <button class="btn text-secondary border-0 bg-primary dropdown-toggle">
                <i class="material-icons" style="font-size: 3em;">keyboard_arrow_down</i>
            </button>
            <!-- Menú desplegable -->
            <ul class="dropdown-menu" style="right: 0; z-index: 20000;">
                <li>
                    <a href='<?php echo "User_page.php?id=" . $_SESSION["id"];?>' class="dropdown-item">Favoritos</a>
                </li>
                <li>
                    <a href='<?php echo "User_page.php?id=" . $_SESSION["id"];?>' class="dropdown-item">Mis imágenes</a>
                </li>
                <li>
                    <!-- <a href="Home (LO).html" class="dropdown-item">Cerrar sesión</a> -->
                    <form action="/Intermemedio/controllers/loginController.php" method="post">
                        <input type="hidden" name="_method" value="DELETE">
                        <input type="submit" value="Cerrar sesión" class="dropdown-item bg-secondary border-0" style="width: 100%; font-size:1em;">
                    </form>
                </li>
            </ul>
        </div>
    </nav>