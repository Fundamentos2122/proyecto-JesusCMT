<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Icon list at https://www.w3schools.com/icons/icons_reference.asp (Scroll down to Google) -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="Framework/css/Framework.css">
    <title>Intermemedio - Home</title>
</head>
<body class = "bg-bg">
    <?php
        //Verificar login
        if(array_key_exists("nombre_usuario", $_SESSION)){
            include("banner LI.php");
        }
        else{
            include("banner LO.php");
        }

        //Validar que el usuario sea administrador
        // if($_SESSION["rol"] !== "admin"){
        //     header("Location: http://localhost/practicaphp/views/");
        //     exit();
        // }
    ?>

    <div class="container-fluid container-lg bg-secondary">
        <?php 
            include ("../controllers/memesController.php");
        ?>
        <div>
        
    </div>

    <script src="Framework/js/framework.js"></script>
</body>
</html>