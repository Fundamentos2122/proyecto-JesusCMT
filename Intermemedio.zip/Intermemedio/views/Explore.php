<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Icon list at https://www.w3schools.com/icons/icons_reference.asp (Scroll down to Google) -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="Framework/css/Framework.css">
    <title>Intermemedio - Explore</title>
</head>
<body class = "bg-bg">
    <?php
        //Verificar login
        if(array_key_exists("nombre_usuario", $_SESSION)){
            include("banner LI.php");
        }
        else{
            include("banner LO.php");
        }

        //Validar que el usuario sea administrador
        // if($_SESSION["rol"] !== "admin"){
        //     header("Location: http://localhost/practicaphp/views/");
        //     exit();
        // }
    ?>    

    <!-- Explorar -->
    <div class="container-fluid container-lg bg-bg  ">
        <div class="row">
            <div class="col-12">
                <h1 style="margin-left: 1em;">Explorar</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-8">
                <h4  style="margin-left: 1em;">Por categoría:</h4>
            </div>
            <div class="col-4">
                <!-- <h4>Ordenar por:</h4> -->
            </div>
        </div>
        <div class="row">
            <div class="col-6"> 
                    <select name="categoria" id="categoria" class="btn" style="width: 100%; text-align: left;">
                        <option value="General" class="dropdown-item">General</option>
                        <option value="Vida Cotidiana" class="dropdown-item">Vida Cotidiana</option>
                        <option value="Escuela" class="dropdown-item">Escuela</option>
                        <option value="Trabajo" class="dropdown-item">Trabajo</option>
                        <option value="Películas y serie" class="dropdown-item">Películas y serie</option>
                        <option value="Videojuegos" class="dropdown-item">Videojuegos</option>
                        <option value="Animales" class="dropdown-item">Animales</option>
                        <option value="Política y sociedad" class="dropdown-item">Política y sociedad</option>
                        <option value="Otros" class="dropdown-item">Otros</option>
                    </select>
                    <br>
                    <button class="btn border-3 border-primary bg-secondary text-primary" style="border-radius: 0.8em; padding: 0.35em; font-size: 1.5em;" id="sendCat" onclick="getMeme()">Filtrar</button>
                <!-- </form> -->
            </div>
            <div class="col-2"></div>
            <div class="col-4">
                <!-- <button style="width: 100%; text-align: left;">
                    <div style="display:flex; justify-content: space-between;">
                        <div>Destacados</div>
                        <i class="material-icons">arrow_drop_down</i>
                    </div>
                </button>
                <ul class="dropdown-menu show" style="right: 1em; left: 1em; width: auto; z-index: 9000;">
                    <li>
                        <a href="" class="dropdown-item">Destacados</a>
                    </li>
                    <li>
                        <a href="" class="dropdown-item">Populares</a>
                    </li>
                    <li>
                        <a href="" class="dropdown-item">Recientes</a>
                    </li>
                </ul> -->
            </div>
        </div>
        <br>
        <!-- <div class="row">
            <div class="col-12">
                <h4 style="margin-left: 1em;">Por tags:</h4>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <input type="text" name="tags" placeholder="Escribe las tags (etiquetas). Ejemplo: 'MCU Marvel Iron-man'">
            </div>
        </div> -->
    </div>

    <div class="container-fluid container-lg bg-secondary" id="list">
    <?php 
        // include("../controllers/memesController.php");
        //phpinfo();
        //include("C:\\xampp/htdocs/Intermemedio/controllers/memesController.php?categoria=General");
    ?>
    </div>
    <script src="Framework/js/framework.js"></script>
    <script>
        function getMeme(){
            
            var xhttp = new XMLHttpRequest();

            var categoriaV = "" + document.getElementById("categoria").value; + "";

            xhttp.open("GET", "../controllers/memesController.php?categoria=" + categoriaV, false);

            xhttp.onreadystatechange = function(){
                if(this.readyState == 4){
                    var list = document.getElementById("list");
                    list.innerHTML = this.responseText;
                }
            }   
            
            xhttp.send();

            let dropdown_buttons =  document.querySelectorAll(`.${dropdown_class} > .${dropdown_toggle}`);
            dropdown_buttons.forEach(element =>{
                element.addEventListener("click", ToggleDropdown);
            });
        }
    </script>
</body>
</html>