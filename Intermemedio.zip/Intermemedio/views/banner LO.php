<nav class="navbar bg-info" style="justify-content: space-between; align-items: flex-end;">
        <!-- Botón de búsqueda (móvil) -->
        <a href="Explore.php" class="navbar-toggle btn text-secondary border-0 bg-primary" type="button">
            <i class="material-icons" style="font-size: 2em;">search</i>
        </a>
        <!-- Opciones izquierda (escritorio) -->
        <div class="navbar-collapse" style="padding: 0.2em 0;">
            <button class="btn text-bg border-0 bg-primary"><i class="material-icons" style="font-size: 2em;">palette</i></button>
            <a href="Explore.php" class="btn text-secondary border-0 bg-primary display-5">Explorar</a>
        </div>
        <!-- Titular -->
        <a href="Home (LO).html" class="navbar-brand h2">Intermemedio</a>
        <!-- Botón menú (móvil) -->
        <div class="navbar-toggle dropdown">
            <button class="navbar-toggle btn text-bg border-0 bg-primary dropdown-toggle" type="button">
                <i class="material-icons" style="font-size: 2em;">menu</i>
            </button>
            <!-- Menú desplegable -->
            <ul class="dropdown-menu" style="right: 0; z-index: 20000;">
                <li>
                    <a href="Sign_up.php" class="dropdown-item">Crear cuenta</a>
                </li>
                <li>
                    <a href="Log_in.php" class="dropdown-item">Iniciar sesión</a>
                </li>
                <li>
                    <a href="" class="dropdown-item">Cambiar colores</a>
                </li>
            </ul>
        </div>
        <!-- Opciones derecha (escritorio) -->
        <div class="navbar-collapse">
            <a href="Sign_up.php" class="btn border-3 border-secondary bg-primary text-secondary display-6" style="border-radius: 0.8em; padding: 0.5em; font-size: 1.5em;">
                Sign up
            </a>
            <a href="Log_in.php" class="btn border-3 border-primary bg-secondary text-primary display-6" style="border-radius: 0.8em; padding: 0.5em; font-size: 1.5em;">
                Log in
            </a>
        </div>
    </nav>

    <div class="lowbar border bg-primary" style="z-index: 9500; text-align: center;">
        <div class="text-secondary" style="font-size: 1.5em;">Intermemedio es mejor con una cuenta:</div>
        <a href="Sign_up.php" class="btn border-3 border-secondary bg-primary text-secondary display-6" style="border-radius: 0.8em; padding: 0.5em; font-size: 1.5em; margin: 0.5em;">
            Sign up
        </a>
        <a href="Log_in.php" class="btn border-3 border-primary bg-secondary text-primary display-6" style="border-radius: 0.8em; padding: 0.5em; font-size: 1.5em; margin: 0.5em">
            Log in
        </a>
    </div>
