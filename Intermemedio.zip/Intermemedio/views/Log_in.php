<?php
    //Verificar login
    session_start();
    if(array_key_exists("nombre_usuario", $_SESSION)){
        header("Location: http://localhost/Intermemedio/");
        exit();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Icon list at https://www.w3schools.com/icons/icons_reference.asp (Scroll down to Google) -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="Framework/css/Framework.css">
    <title>Intermemedio - Log in</title>
</head>
<body class="bg-primary text-primary">
    <div class="container-fluid container-lg bg-primary">
        <div class="row" style="height: 10vh;"></div>
        <div class="row">
            <div class="col-12" style="text-align: center;">
                <a href="Home (LO).html"  style="text-decoration: none;">
                    <h1 class="display-4 text-secondary">Intermemedio</h1>
                </a>
            </div>
        </div>
    </div>
    <div class="container-fluid container-lg bg-secondary">
        <div class="row">
            <div class="col-4"></div>
            <div class="col-4" style="text-align: center;">
                <h3>Log in</h3>
            </div>
        </div>
        <?php
            if(array_key_exists("error", $_GET)){
                echo '<div class = "bg-danger border show text-secondary">' . $_GET["error"] . '</div>';
            }
        ?>
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">
                <form action="../controllers/loginController.php" method="POST">
                    <input type="hidden" name="_method" value="POST">
                    <label for="correo">Correo electrónico</label>
                    <input type="text" name="correo" autocomplete="off" required>
                    <br>
                    <label for="contrasena">Contraseña</label>
                    <input type="password" name="contrasena" autocomplete="off" required>
                    <br><br>
                    <div style="text-align: center;">
                        <input type="submit" class="btn border-3 border-primary bg-secondary text-primary display-5" style="border-radius: 0.8em; padding: 0.35em; font-size: 2em;" value="Iniciar sesión"></input>
                        <br><br>
                        <a href="Sign_up.php" class="btn border-3 border-secondary bg-primary text-secondary display-6" style="border-radius: 0.8em;">Crear cuenta nueva</a>
                    </div>
                </form>
            </div>
        </div>
        <br>
    </div>
</body>
</html>