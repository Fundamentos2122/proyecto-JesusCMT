<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Icon list at https://www.w3schools.com/icons/icons_reference.asp (Scroll down to Google) -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="Framework/css/Framework.css">
    <title>Intermemedio - Pagina de usuario</title>
</head>
<body>
    <?php
        //Verificar ID
        if(!array_key_exists("id", $_GET)){

            header("Location: http://localhost/Intermemedio/views/Home (LI).php");
            exit();
        }
        $id = $_GET["id"];

        //Verificar login
        if(array_key_exists("nombre_usuario", $_SESSION)){
            include("banner LI.php");
        }
        else{
            include("banner LO.php");
        }

        //Validar que el usuario sea administrador
        // if($_SESSION["rol"] !== "admin"){
        //     header("Location: http://localhost/practicaphp/views/");
        //     exit();
        // }
    ?>    

    <div class="bg-secondary">
        <div class="container-fluid container-lg">
            <div class="row">
                <div class="col-1"></div>
                <div class="col-1" style="margin: 0; padding: 0.35em;">
                    <img src="Imagenes/PP.png" alt="Profile Picture" class="profilePic">
                </div>
                <div class="col-9">
                    <h1 class="<?php echo "username" . $id;?>"></h1>
                </div>
            </div>
            <br><br>
            <div class="row">
                <h4>Memes subidos</h4>
            </div>
            <br>
            <div class="row" style="flex-wrap: wrap; justify-content: space-between;" id="memeDiv">
                <div style="height: 12em; margin: 0.5em;" class="border">
                    <a href="Meme comentarios (LI).html">
                        <img src="Imagenes/M10.jpg" alt="Meme" class="meme">
                    </a>
                </div>
                <div style="height: 12em; margin: 0.5em;" class="border">
                    <img src="Imagenes/M09.jpg" alt="Meme" class="meme">
                </div>
                <div style="height: 12em; margin: 0.5em;" class="border">
                    <img src="Imagenes/M03.jpg" alt="Meme" class="meme">
                </div>
                <div style="height: 12em; margin: 0.5em;" class="border">
                    <img src="Imagenes/M01.png" alt="Meme" class="meme">
                </div>
            </div>
        </div>
    </div>

    <div class="bg-bg">
        <div class="container-fluid container-lg">
            <br>
            <div class="row">
                <h4>Favoritos</h4>
            </div>
            <br>
            <!-- <div class="row" style="flex-wrap: wrap; justify-content: space-between;">
                <div style="height: 12em; margin: 0.5em;" class="border">
                    <a href="Meme comentarios (LI).html">
                        <img src="Imagenes/M10.jpg" alt="Meme" class="meme">
                    </a>
                </div>
                <div style="height: 12em; margin: 0.5em;" class="border">
                    <img src="Imagenes/M09.jpg" alt="Meme" class="meme">
                </div>
                <div style="height: 12em; margin: 0.5em;" class="border">
                    <img src="Imagenes/M08.jpg" alt="Meme" class="meme">
                </div>
                <div style="height: 12em; margin: 0.5em;" class="border">
                    <img src="Imagenes/M07.jpg" alt="Meme" class="meme">
                </div>
                <div style="height: 12em; margin: 0.5em;" class="border">
                    <img src="Imagenes/M06.jpg" alt="Meme" class="meme">
                </div>
                <div style="height: 12em; margin: 0.5em;" class="border">
                    <img src="Imagenes/M04.png" alt="Meme" class="meme">
                </div>
                <div style="height: 12em; margin: 0.5em;" class="border">
                    <img src="Imagenes/M03.jpg" alt="Meme" class="meme">
                </div>
            </div>
            <div class="row">
                <a href="Favoritos (LI).html" class="btn border-3 border-secondary bg-primary text-secondary display-5" style="border-radius: 0.8em;">
                    Ver más
                </a>
            </div> -->
        </div>
    </div>

    <div class="bg-secondary">
        <div class="container-fluid container-lg">
            <br>
            <div class="row">
                <h4>Comentarios</h4>
            </div>
            <div id="comDiv"></div>
            <br>
            
        </div>
    </div>

    <script src="Framework/js/framework.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function(){
            id = <?php echo $id;?>;
            getUsername(id);
            getMeme();
            getComentario();
        });

        function getUsername(id){
            let divs =  document.querySelectorAll(".username" + id);

            divs.forEach(element =>{
                var xhttp = new XMLHttpRequest();
        
                xhttp.open("GET", "../controllers/accountController.php?id=" + id, false);
        
                xhttp.onreadystatechange = function(){
                    if(this.readyState == 4){
                        var User = JSON.parse(this.responseText);
                        element.innerHTML =User.nombre_usuario;
                    }
                };
        
                xhttp.send();
            });
        }

        function getMeme(){
            
            var xhttp = new XMLHttpRequest();

            var id = '<?php echo $id; ?>';

            xhttp.open("GET", "../controllers/memesController.php?usuario_id=" + id, false);

            xhttp.onreadystatechange = function(){
                if(this.readyState == 4){
                    var list = document.getElementById("memeDiv");
                    list.innerHTML = this.responseText;
                }
            }
            xhttp.send();
        }

        function getComentario(){
            
            var xhttp = new XMLHttpRequest();

            var id = '<?php echo $id; ?>';

            xhttp.open("GET", "../controllers/comentarioController.php?usuario_id=" + id, false);
            xhttp.onreadystatechange = function(){
                if(this.readyState == 4){
                    var comDiv = document.getElementById("comDiv");
                    comDiv.innerHTML = this.responseText;
                }
            }
            xhttp.send();
        }
    </script>
</body>
</html>