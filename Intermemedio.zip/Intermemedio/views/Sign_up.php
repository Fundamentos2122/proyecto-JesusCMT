<?php
    //Verificar login
    session_start();
    if(array_key_exists("nombre_usuario", $_SESSION)){
        header("Location: http://localhost/Intermemedio/");
        exit();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Icon list at https://www.w3schools.com/icons/icons_reference.asp (Scroll down to Google) -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="Framework/css/Framework.css">
    <title>Intermemedio - Sign up</title>
</head>
<body class="bg-primary text-secondary">
    <div class="container-fluid container-lg">
        <div class="row" style="height: 10vh;"></div>
        <div class="row">
            <div class="col-12" style="text-align: center;">
                <a href="Home (LO).html"  style="text-decoration: none;">
                    <h1 class="display-4 text-secondary">Intermemedio</h1>
                </a>
            </div>
        </div>
        <div class="row">
            <div class="col-4"></div>
            <div class="col-4" style="text-align: center;">
                <h3>Sign up</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-3"></div>
            <div class="col-6">
                <form action="../controllers/accountController.php" method="POST">
                    <input type="hidden" name="_method" value="POST">
                    <label for="correo">Correo electrónico</label>
                    <input type="text" name="correo" autocomplete="off" required>
                    <br>
                    <label for="nombre_usuario">Nombre de usuario</label>
                    <input type="text" name="nombre_usuario" autocomplete="off" required>
                    <br>
                    <label for="contrasena">Contraseña</label>
                    <input type="password" name="contrasena" autocomplete="off" required>
                    <br><br>
                    <div style="text-align: center;">
                        <input type="submit" class="btn border-3 border-secondary bg-primary text-secondary display-5" style="border-radius: 0.8em; padding: 0.35em; font-size: 2em;" value="Crear cuenta"></input>
                        <br><br>
                        <a href="Log_in.php" class="btn border-3 border-primary bg-secondary text-primary display-6" style="border-radius: 0.8em;">Ya tengo una cuenta</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>