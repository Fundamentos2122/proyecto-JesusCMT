<?php

    class Comentario{
        private $_id;
        private $_meme_id;
        private $_usuario_id;
        private $_texto;
        private $_num_likes;

        public function __construct($id, $meme_id, $usuario_id, $texto, $num_likes){
            $this->setId($id);
            $this->setMemeId($meme_id);
            $this->setUsuarioId($usuario_id);
            $this->setTexto($texto);
            $this->setNumLikes($num_likes);
        }

        public function getId(){
            return $this->_id;
        }

        public function setId($id) {
            $this->_id = $id;
        }

        public function getMemeId(){
            return $this->_meme_id;
        }

        public function setMemeId($meme_id) {
            $this->_meme_id = $meme_id;
        }

        public function getUsuarioId(){
            return $this->_usuario_id;
        }

        public function setUsuarioId($usuario_id) {
            $this->_usuario_id = $usuario_id;
        }

        public function getTexto(){
            return $this->_texto;
        }

        public function setTexto($texto) {
            $this->_texto = $texto;
        }

        public function getNumLikes(){
            return $this->_num_likes;
        }

        public function setNumLikes($num_likes) {
            $this->_num_likes = $num_likes;
        }
    }

?>