<?php 

    class Meme {
        private $_id;
        private $_imagen;
        private $_usuario_id;
        private $_categoria;
        private $_tags;
        private $_num_likes;

        public function __construct($id, $imagen, $usuario_id, $categoria, $tags, $num_likes){
            $this->setId($id);
            $this->setImagen($imagen);
            $this->setUsuarioId($usuario_id);
            $this->setCategoria($categoria);
            $this->setTags($tags);
            $this->setNumLikes($num_likes);
        }

        public function getId(){
            return $this->_id;
        }
        public function setId($id){
            $this->_id = $id;
        }

        public function getImagen(){
            return $this->_imagen;
        }
        public function setImagen($imagen){
            $this->_imagen = base64_encode($imagen);
        }

        public function getUsuarioId(){
            return $this->_usuario_id;
        }
        public function setUsuarioId($usuario_id){
            $this->_usuario_id = $usuario_id;
        }
        
        public function getCategoria(){
            return $this->_categoria;
        }
        public function setCategoria($categoria){
            $this->_categoria = $categoria;
        }
        
        public function getTags(){
            return $this->_tags;
        }
        public function setTags($tags){
            $this->_tags = $tags;
        }

        public function getNumLikes(){
            return $this->_num_likes;
        }
        public function setNumLikes($num_likes){
            $this->_num_likes = $num_likes;
        }
        
        public function returnJson(){
            $meme = array();

            $meme["id"] = $this->getId();
            $meme["imagen"] = $this->getImagen();
            $meme["usuario_id"] = $this->getUsuarioId();
            $meme["categoria"] = $this->getCategoria();
            $meme["tags"] = $this->getTags();
            $meme["num_likes"] = $this->getNumLikes();

            echo json_encode($meme);
        }
        
    }

?>